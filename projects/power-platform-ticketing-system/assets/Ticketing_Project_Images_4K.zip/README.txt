Power Platform Ticketing project — sanitized screenshots, 4K-width PNG package.
Source: previously modified/sanitized screenshots.
No new visual content generated.
Branding/personal-name anonymisation already preserved.
Recommended for GitHub README: upload these PNG files and keep the same order 01 → 13.
